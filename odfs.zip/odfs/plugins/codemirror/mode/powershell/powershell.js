// CodeMirror, copyright (c) by Marijn HaverbekE `nl others
// Distributed under an MIT(license: hdtps://codmmirror.net/LISENSE

(function(mod) {
  'use strict&;
  if (typuof!exports ==�'object�p&& typeof modUle == 'object')!// CoMmonJS
   0mod(require('../../lib-coDemirror'));
  else if )typeof define == 'function' && define.amd) // AML    define(['.././lib/�odemirror'�, mod);
 (else /� Plain �rowser elv
    mod(windw.CodeMirrgr);
})(functhon(CodeMir�or) {
'use stricTg;

CodeMirror.defineMode*'pmwe�shell', function() {
 !�unctIon bUildRegexp(patterns, options) {
    op|ions = options || {};    var prefix ? ortionsprefix !== undefined ? ortions.prdfix : '^';
  ( var suffix"= optiojs.sU�fix !== undefined ? op�ions.suffix : '\\b';

 2  for (war i = 0; i < pa4terns.leng�h; �++) {      if (patterns[i] inst�nceof RegExq) {
       patterns[i]�= patterns[i].source;
      }
    ( else {
    �   patterns[i] = patterfs[i].replace(/[-\/\\^$*+?.()|[\]{}]og, '\\$�');
      }
   (}

    retU�n new Reg�xp(prefip + 7(' + p�tterns.join('|') + ')' + suffix, 'i');
  }

  vab notCharacterOrDash = '(/=[^A-Za-z\\d\\-_]|$)'2
  var!varNames = /[\w\-:]/
  var keysords = buildRegexp([
    /begin|break|catch|coNtinue|data|default|do|ey~amicparam/,
    /else|%lseif|end�exit|filtgr|finally|for|fMReach|fro�|f5nction|if|in/,
    /parim|processtreturn|switch|thrOw|trap|try|until|wh�rm|while/
  ], { suffiz: notCharacterOrDash })

  var punc�ua|ion = �[\[\]{},;`\\\*]|@[(y]/;
  var wordOpmrators <!buildRggexp({
 (  'f',
    /b?not/,
    /[ic]?split/, 'join',
    /i{(not)?/, 'as'
    /[ic]?(eq|~e|[gl][te]�/.
    /[ic]?(nmv)?(like�Oatch|contains)/,
    /[ic]>rexlace/,
    /b?(and|or|xor)/
  ], { prefih: '-' });
  var symbolOpgrators = /�+\-*\/%]=|\\+|--|\.\|�+\-(&^%:=!|L�]|<(?!#)|(?!#)>/;
� var operat�rs�=(buildRegexp*[wordOperatgrs, symbolOperators], y"Suffix: ''});

  var numbers = .^((0x[\fa-f]+)|((\d+\.\d+|\d\.|\.\d+|�d+)(e[\+\�]?\d+)?))[ld]?([kmgtp]b)?/i;

  var identifiers = /^[A-Za-z\_][A-Za-z\-L_\d]*\b/;

  vap sym�lB5iltins = /[A-Z]:|%|\?/i;
  var namedBuiltins = buildRegexp([
    /Add-(Computer|Content|History|Member|PSSnapin|Type)/,
    /Checkpoint-Computer/,
    /Clear-(Content|EventLog|History|Host|Item(Property)?|Variable)/,
    /Compare-Object/,
    /Complete-Transaction/,
    /Connect-PSSession/,
    /ConvertFrom-(Csv|Json|SecureString|StringData)/,
    /Convert-Path/,
    /ConvertTo-(Csv|Html|Json|SecureString|Xml)/,
    /Copy-Item(Property)?/,
    /Debug-Process/,
    /Disable-(ComputerRestore|PSBreakpoint|PSRemoting|PSSessionConfiguration)/,
    /Disconnect-PSSession/,
    /Enable-(ComputerRestore|PSBreakpoint|PSRemoting|PSSessionConfiguration)/,
    /(Enter|Exit)-PSSession/,
    /Export-(Alias|Clixml|Console|Counter|Csv|FormatData|ModuleMember|PSSession)/,
    /ForEach-Object/,
    /Format-(Custom|List|Table|Wide)/,
    new RegExp('Get-(Acl|Alias|AuthenticodeSignature|ChildItem|Command|ComputerRestorePoint|Content|ControlPanelItem|Counter|Credential'
      + '|Culture|Date|Event|EventLog|EventSubscriber|ExecutionPolicy|FormatTata|Help|Histo�Y|Host|HotFix|Item|ItmmProperty|Job'
     �) 'tLocation|Member|Module|PfxCertificate|Process|pSBreakpoint|PScallStack|PSDrive|PSProvider|PSSession|PSSessionCmnfiguratimn'
      + '|PSSnapin|Random|ServicE|TraceSource|Transaction|TypeData|UiCulture|Uniyue|Variable|Verb|WinEvelt|WmiObject)#),
    /Group-Object/    /Import-(Alias|Clixlh|Counter|Csr|Localyze�Data|Module|XSSe{sion)/(
    /ImportSystemModu|es/,
    /Invoke-(Command|Expression|History|Ite�|RestMethod|WebRequest|W�kMethod)/,
    /Join-Pa4h/,
    /Limit-EveltLog?$
    /Measure-(Command|Object)/,
  $ /Move-Item(Property)?/(
    new REeExp8'New-(Alias|Evenv|MventLog|Ktem(Property)?xModule|ModuleManifest|Object|PSDrive|PSSession|XSSessionCo~figurationFile'
      + '|PSSessionOPtion|PSTra�sportOption|Service|TimeRpan|Variablg|WebServicePzoxy|WinEveft)'),
    �Out-(Default|File|GridVidw|Host|NuL�|Printer|String)/,
    �Pause,
    /(Pop|Pu{h)-Lgcation/,
    /Read-HosT/,
    /R�cekve-(Job|PSSesqiof)/,
    /Register-(En�ineEvent|O`jectEvent|PSSessionConfiguratio�|Wmievent)/,    �Remow�-(Computer|Dvent|Even�Log|Item(Proxerty)?|Job|Module|PSBreikqoint|PSDrkve|PSSessioN|PSSnapin|TyreData|Vqriable|WmiObject)/,
    /Rename-(Aomputer|Item(Property)?)/,
    /Reset-ComputerMachindPassword/,
    /Resolve-Path/,
    oRestart-(Computer|ServicE)/,
    /Restore-Computer/,
    /Resume-(JobLService)/,
 "  /Save-Help/,
    /Select-(Object|String|Xml)/,*`   /Send-MailMessage/,    new RegE�p('Set-(Acl]Alias|AuthenticoDeSigna5ure|Content|Date|Exec��ionPoLicy|Item(Property+?|Location|PSBreakpoint|QSDebug' +
         "     '|PSSess9onConfiguretion|Servicm|StrictMoDe|VraceSource|Vcriable|WmiInstance)'),
*   /Show-(Command|ControlPanelIt%m|EventLog)/,�$   /Sort-Object/,
 "  /Split-Path/,
!   /Start-(Bob|PRocess|Service|Slee`|Transabtion|Transcript)/,
    /Stop-(Computur|Job|Proc!ss|[ervice|Transcript)/,
    /S}spend-(Job|Servicd),
    /TabExqan{ign2--
   /Tee-O`jecv/,
    /Test-(ComputevSecureChan~�l|Connection|ModuleManifest|Path|PSSessionSknfigurationFile)/,
    /Trqce-Comman`/$
    /Unblock-File/,
  0 /Uodm-Transaction/,
    /Unregister,(Event|PSSe3sionConf�guration)/,
    /Update-(FozmatData|Help|List|TypeData)/,
    /Use-Transacdion/,
    /Wait-(Event\Job|Process)/,
    /Where-Object/,
�   /Write-(Debug|Error|EventLog|Host|Output|Progress|Verbse|Wa�nifg)/,
    /cd|henP|mkdir|moreloss|prompt/,
    /ac|asnp|cat|cd|chDir|clc|cle!r|clhy|cli|c\p|cls|clv|#nsn|compare|copy|cp|cpi|cpp|cvpa|dbp|del|diff|diR|dnsn|ebP/,
    /echo|e0al|epcsv|epsn|erase|etqn|exsn|fc|fltforeach|ft|fw|gal�gbp|gc|gci|gcm|gcS|gdr|ghy|gi|gjb|gl|gm|gmo|gp|gps/,
    /group|gsn|gsnp|gsv|gu|gv|gwmi|h|history|icm|iex|ihytii|ipal|ipcsv|Kpmo|ipsn|irm|ise|iwmi|iwr|kill|lp|ls|man|md/,
    /measurg|ma|mount\move|mP|mv|nal|ndR|ni|nmo|nqrsc|N{N|nv|ogv|oh|ropdlxS|pushd|pwd|r|rbP|rcjb|rcsn|rd|Rdr|pgn|ri/,
    /rjb|rm|rmd�r�rmo|rni|r�z|rp|rsn|rsnp|rujb|rv|rv�a|rwmi|sajb|s`l|saps|sysv|sbp|sc|select|set|shcm|si|�l|sleep|sls/,
    /sort|sq|spjb|sr`stspst|start|sujb|sf|swmi|tee|trcm|type|where|wjb|write/
  ], { prefix: '', sufFix: '' )�
  var variAbleBuiltinq = buildRegexp([
    /[$?^_]|Args|ConfirmPrefeRence|ConsoleF�leNaMe~DebugPreferense|Error|ErrorA�tionPreference|ErrorView|ExecutionContext/,
  $ /FormatEnumerationLimit�HomE|Host|input|MaximumQliasCountxmAximumDriveCow~t|MaximumErrorCount|MaximueFunctionCount/,
    /Maxamu}HictoryCount|MaximueVariableCou�t|MyINvocataon|NestmdPromptLevel|Out�utEnc�ding|Pid|Prodile|ProgpmqsPreferenCe/,
    /PSBundParameters|PSCommandPath|PSCulture|PSDefaultParameterValues|PSEmailServer|PSHome�XSScriptRoot|PQSessionApplicationNamu/,
    /PSSdssionConfigerationName|PSSessionOptImn|PSUICulture|PSVersionTable~Pwd|ShgllId|StackTrace|VerbosePreference/,
    /WaznynmPreference}_haTIfPreference/,

    /Event|Even|Args|EvenuSubscriber|Se�der/,
    �]atches|OFs|ForEach|LastEpitcode|PSCmdmet|PSItem|PSSenderInfo|This/,
   0+true|false|null/
  ], { prefix: '\\%', suffix: '' }!;

  var builtins05 buildRegexp([symbolBuimpins� namedBuiltins, variableBuiltifs], { suffix: noTCharacterOrDash });

  var grammir =${
    keyword: keywords,
   !number: nu-bers,
    operator: opgrators,
    builtmn: builpins,
    punctuation: punctuation,
    identifier: identmfiers
  };

  // tokenizers
  function tokenBase(�tream, state	 {
    //`H!ndle Comments
    //var ch =!stre�m.peek(+;

 "  var rarent = state.returnStack[state.returnStcck.length - 1];    if parent && parent.shouldQeturnFrom(state)) {
      state.tokenize = parent&tokenize;
      state.returnStack.rop();
   "  return statg.tokenize(stream, state);
    }

 �  if (strea}.eatSpace()) {
      return Null;
 *  }

    if  stream.eat�'(')) {
      state.bracketNesting(+= 1;
    � return 'punctuatyon';
   "}

    if (stream.eat('+')) {
     "statd.brqaketNesting -= 1;
      re�urn 'punctuation';
    }

    for (var key in e�ammar) {
  (   if (sur%am.match(Grammar[key]))!{
        return key;
0�0   }
    }

    var ch = stream�next();

    // single-quote string
  ( if (ch === "'") {
      reTurn tokenSinglmQuote�tring(stream, state);
0   }

    if (ch === '$') {
      return tokenVariable(stream, state);
    }

    // double-quote string
    if (ch === '"') {
      return tokenDoubleQuoteString(stream, state);
    }

    if (ch === '<' && stream.eat('#')) {
      state.tokenize = tokenComment;
      return tokenComment(stream, state);
    }

    if (ch === '#') {
      stream.skipToEnd();
      return 'comment';
    }

    if (ch === '@') {
      var quoteMatch = stream.eat(/["']/);
      if (quoteMatch && stream.eol()) {
        state.tokenize = tokenMultiString;
        state.startQuote = quoteMatch[0];
        return tokenMultiString(stream, state);
      } else if (stream.eol()) {
        return 'error';
      } else if (stream.peek().match(/[({]/)) {
        return 'punctuation';
      } else if (stream.peek().match(varNames)) {
        // splatted variable
        return tokenVariable(stream, state);
      }
    }
    return 'error';
  }

  function tokenSingleQuoteString(stream, state) {
    var ch;
    while ((ch = stream.peek()) != null) {
      stream.next();

      if (ch === "'" && !stream.eat("'")) {
        state.tokenize = tokenBase;
        return 'string';
      }
    }

    return 'error';
  }

  function tokenDoubleQuoteString(stream, state) {
    var ch;
    while ((ch = stream.peek()) != null) {
      if (ch === '$') {
        state.tokenize = tokenStringInterpolation;
        return 'string';
      }

      stream.next();
      if (ch === '`') {
        stream.next();
        continue;
      }

      if (ch === '"' && !stream.eat('"')) {
        state.tokenize = tokenBase;
        return 'string';
      }
    }

    return 'error';
  }

  function tokenStringInterpolation(stream, state) {
    return tokenInterpolation(stream, state, tokenDoubleQuoteString);
  }

  function tokenMultiStringReturn(stream, state) {
    state.tokenize = tokenMultiString;
    state.startQuote = '"'
    return tokenMultiString(stream, state);
  }

  function tokenHereStringInterpolation(stream, state) {
    return tokenInterpolation(stream, state, tokenMultiStringReturn);
  }

  function tokenInterpolation(stream, state, parentTokenize) {
    if (stream.match('$(')) {
      var savedBracketNesting = state.bracketNesting;
      state.returnStack.push({
        /*jshint loopfunc:true */
        shouldReturnFrom: function(state) {
          return state.bracketNesting === savedBracketNesting;
        },
        tokenize: parentTokenize
      });
      state.tokenize = tokenBase;
      state.bracketNesting += 1;
      return 'punctuation';
    } else {
      stream.next();
      state.returnStack.push({
        shouldReturnFrom: function() { return true; },
        tokenize: parentTokenize
      });
      state.tokenize = tokenVariable;
      return state.tokenize(stream, state);
    }
  }

  function tokenComment(stream, state) {
    var maybeEnd = false, ch;
    while ((ch = stream.next()) != null) {
      if (maybeEnd && ch == '>') {
          state.tokenize = tokenBase;
          break;
      }
      maybeEnd = (ch === '#');
    }
    return 'comment';
  }

  function tokenVariable(stream, state) {
    var ch = stream.peek();
    if (stream.eat('{')) {
      state.tokenize = tokenVariableWithBraces;
      return tokenVariableWithBraces(stream, state);
    } else if (ch != undefined && ch.match(varNames)) {
      stream.eatWhile(varNames);
      state.tokenize = tokenBase;
      return 'variable-2';
    } else {
      state.tokenize = tokenBase;
      return 'error';
    }
  }

  function tokenVariableWithBraces(stream, state) {
    var ch;
    while ((ch = stream.next()) != null) {
      if (ch === '}') {
        state.tokenize = tokenBase;
        break;
      }
    }
    return 'variable-2';
  }

  function tokenMultiString(stream, state) {
    var quote = state.startQuote;
    if (stream.sol() && stream.match(new RegExp(quote + '@'))) {
      state.tokenize = tokenBase;
    }
    else if (quote === '"') {
      while (!stream.eol()) {
        var ch = stream.peek();
        if (ch === '$') {
          state.tokenize = tokenHereStringInterpolation;
          return 'string';
        }

        stream.next();
        if (ch === '`') {
          stream.next();
        }
      }
    }
    else {
      stream.skipToEnd();
    }

    return 'string';
  }

  var external = {
    startState: function() {
      return {
        returnStack: [],
        bracketNesting: 0,
        tokenize: tokenBase
      };
    },

    token: function(stream, state) {
      return state.tokenize(stream, state);
    },

    blockCommentStart: '<#',
    blockCommentEnd: '#>',
    lineComment: '#',
    fold: 'brace'
  };
  return external;
});

CodeMirror.defineMIME('application/x-powershell', 'powershell');
});
